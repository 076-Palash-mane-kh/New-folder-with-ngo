import React from "react";

function AboutUs() {
  return <div>AboutUs</div>;
}

export default AboutUs;
