import React from 'react'

function Forgotpassword() {
  return (
    <div>Forgotpassword</div>
  )
}

export default Forgotpassword