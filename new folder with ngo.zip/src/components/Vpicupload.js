import React from 'react'

function Vpicupload() {
  return (
<div></div>
  )
}

export default Vpicupload